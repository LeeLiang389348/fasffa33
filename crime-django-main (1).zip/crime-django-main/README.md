 
<img width="752" alt="image" src="https://github.com/minh1609/crime-django/assets/39399443/3d2cc440-648b-4711-8ea1-f153c6d7ccc3">
